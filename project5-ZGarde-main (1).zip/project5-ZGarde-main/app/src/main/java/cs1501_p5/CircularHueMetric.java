package cs1501_p5;

public class CircularHueMetric implements DistanceMetric_Inter {

    /**
     * Computes the circular hue distance between two pixels.
     * @param p1 the first pixel
     * @param p2 the second pixel
     * @return The circular hue distance between p1 and p2
     */

     //0 pure red 120 pure green 240 pure blue, getHue in Pixel, Max=359, min=0
    @Override
    public double colorDistance(Pixel p1, Pixel p2) {
        int Min=0;
        int Max=359;
        int hue1 = p1.getHue();
        int hue2 = p2.getHue();

        
        if(hue1>Max){
            return -1;
        }
        if(hue1<Min){
            return -1;
        }
        if(hue2>Max){
            return -1;
        }
        if(hue2<Min){
            return -1;
        }
         
        int diff = Math.abs(hue1 - hue2);

        return Math.min(diff, 360 - diff);//a circle,min( 20-340, 360-340) 
    }
}
