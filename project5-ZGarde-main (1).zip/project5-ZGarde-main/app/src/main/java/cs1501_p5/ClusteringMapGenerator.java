package cs1501_p5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//kmeans

public class ClusteringMapGenerator implements ColorMapGenerator_Inter {
    private DistanceMetric_Inter metric;

    public ClusteringMapGenerator(DistanceMetric_Inter metric) {
        this.metric = metric;
    }

    @Override
    public Pixel[] generateColorPalette(Pixel[][] pixelArray, int numColors) {
        Pixel[] palette = new Pixel[numColors];
        int cnt=0;
        palette[cnt]= pixelArray[0] [0]; //Pick the first initial color as the first pixel in the .bmp image: the color of (0, 0)
        cnt++;


        while(cnt<numColors){
            Pixel furthest=null;
            double maxDist = -1;
            int maxRGB =-1; 
            int rowNum=pixelArray.length;
            int colNum=pixelArray[0].length;
            for(int i=0;i<rowNum;i++){
                for(int j=0;j<colNum;j++ ){
                    Pixel temp=pixelArray[i][j];
                    double minDist=Double.MAX_VALUE;
                    for(int n=0;n<cnt;n++){
                        double distance = metric.colorDistance(temp,palette[n]);
                        if(distance<minDist){
                            minDist=distance;// update the minDistance
                        }
                    }
                    /* 
                    if(minDist>maxDist){
                        maxDist=minDist;
                        furthest=pixel;
                        int r=pixel.getRed()<<16;
                        int g=pixel.getGreen()<<8;
                        int b=pixel.getBlue();
                        int colorValue=r|g|b;
                        maxRGB=colorValue;
                    }

                    if(minDist==maxDist){
                        int r=pixel.getRed()<<16;
                        int g=pixel.getGreen()<<8;
                        int b=pixel.getBlue();
                        int colorValue=r|g|b;
                        if(colorValue>maxRGB){
                            furthest=pixel;
                            maxRGB=colorValue;
                        }
                    }
                    */
                    /* 
                    if(minDist>=maxDist){
                        int r=pixel.getRed()<<16;
                        int g=pixel.getGreen()<<8;
                        int b=pixel.getBlue();
                        int colorValue=r|g|b;
                        if(minDist>maxDist){
                            furthest=pixel;
                            maxRGB=colorValue;
                        }else{
                            if(maxRGB<colorValue){
                                maxRGB=colorValue;
                                furthest=pixel;
                            }
                        }
                        maxDist=minDist;
                    }
                    */

                    //I write a method in pixel to get rgb value
                    if(minDist>maxDist || (minDist==maxDist && ((temp.getRed()<<16) | (temp.getGreen()<<8) | (temp.getBlue())) > maxRGB)){
                        maxDist=minDist;
                        maxRGB=((temp.getRed()<<16) | (temp.getGreen()<<8) | (temp.getBlue()));
                        furthest=temp;
                    }



                }
            }
            palette[cnt]=furthest;
            cnt++;
        }
        return palette;
    }

    
    
/*Expected: (125,125,125) | Actual: (144,2,2) | FAIL*********
A pixel was mapped to the incorrect reduced color in Clustering

Expected: (200,200,200) | Actual: (225,2,2) | FAIL*********
A pixel was mapped to the incorrect reduced color in Clustering

Expected: (200,200,200) | Actual: (225,2,2) | FAIL*********
A pixel was mapped to the incorrect reduced color in Clustering

Expected: (200,200,200) | Actual: (225,2,2) | FAIL*********
A pixel was mapped to the incorrect reduced color in Clustering

Expected: (250,250,250) | Actual: (225,2,2) | FAIL*********
A pixel was mapped to the incorrect reduced color in Clustering

Expected: (250,250,250) | Actual: (225,2,2) | FAIL*********
A pixel was mapped to the incorrect reduced color in Clustering

Expected: (250,250,250) | Actual: (225,2,2) | FAIL*********
A pixel was mapped to the incorrect reduced color in Clustering */
    


    @Override
    public Map<Pixel, Pixel> generateColorMap(Pixel[][] pixelArray, Pixel[] initialColorPalette){
        Map<Pixel, Pixel> colorMap=new HashMap<>();
        Map<Pixel,List<Pixel>> clusters= new HashMap<>();
        for(Pixel centroid: initialColorPalette){//Chosse the centroid from the initialColorPalette
            clusters.put(centroid,new ArrayList<>()); //initialize
        }
        boolean changed=true;
        while (changed) {
            changed=false;
            //int rowNum=pixelArray.length;
            //int colNum=pixelArray[0].length;
            for(Pixel[] row:pixelArray){
                for(Pixel pixel : row ){
                    //Pixel temp=pixelArray[i][j];
                    Pixel closest=null;
                    double minDist=Double.MAX_VALUE;
                    for(Pixel centroid: clusters.keySet()){// this loop is to find the closest centroid of pixelArray[i][j]
                        double dist=metric.colorDistance(pixel, centroid);
                        if(dist<minDist){
                            minDist=dist;
                            closest=centroid;
                        }
                    }
                    clusters.get(closest).add(pixel);//add the the pixelArray[i][j] to its centroid after the loop
                    if(!closest.equals(colorMap.get(pixel))){
                        colorMap.put(pixel,closest);
                        changed=true;//End if the pixel's centroid already in colorMap
                    }
                }
            }
            //update the centroid position
            Map<Pixel,List<Pixel>> clusterNew= new HashMap<>();// Temp
            for(Pixel centroid: clusters.keySet()){
                List<Pixel> tempList=clusters.get(centroid);
                int r=0;
                int g=0;
                int b=0;
                /*I had a problem that I set  r=r+pixel.getRed(); and I got error above, I changed it to r+=pixel.getRed(), and its correct. After I changed it back, its correct again */
                for(Pixel pixel:tempList){
                    r=r+pixel.getRed();
                    g=g+pixel.getGreen();
                    b=b+pixel.getBlue();
                }
                if(tempList.size()>0){
                    r=r/tempList.size();
                    g=g/tempList.size();
                    b=b/tempList.size();
                    Pixel tempKey= new Pixel(r, g, b);
                    clusterNew.put(tempKey,tempList);//cant put clusters, would change the clusters after the first loop.
                }
            }
            clusters=clusterNew;
        }
        return colorMap;


    }

   

}
