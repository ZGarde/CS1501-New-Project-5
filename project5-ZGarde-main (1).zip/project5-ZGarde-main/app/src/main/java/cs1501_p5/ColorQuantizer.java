package cs1501_p5;

import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.util.Map;

public class ColorQuantizer implements ColorQuantizer_Inter {
    private Pixel[][] pixelArray;
    private ColorMapGenerator_Inter gen;

    // Constructor for using a pixel array directly
    public ColorQuantizer(Pixel[][] pixelArray, ColorMapGenerator_Inter gen) {
        this.pixelArray=pixelArray;
        this.gen=gen;
        
    }

    // Constructor for reading from a BMP file
    public ColorQuantizer(String bmpFilename, ColorMapGenerator_Inter gen) throws Exception {
        BufferedImage image=ImageIO.read(new File(bmpFilename));
        this.pixelArray=Util.convertBitmapToPixelMatrix(image);
        this.gen= gen;
    }

    @Override
    public Pixel[][] quantizeTo2DArray(int numColors) {
        Pixel[] initialColorPalette=gen.generateColorPalette(pixelArray, numColors);
        Map<Pixel, Pixel> colorMap = gen.generateColorMap(pixelArray, initialColorPalette);
        int rowNum=pixelArray.length;
        int colNum=pixelArray[0].length;
        Pixel[][] result = new Pixel[rowNum][colNum];

        for (int i = 0; i < pixelArray.length; i++) {
            for (int j = 0; j < pixelArray[i].length; j++) {
                result[i][j] = colorMap.get(pixelArray[i][j]);
            }
        }
        return result;
    }

    @Override
    public void quantizeToBMP(String fileName, int numColors) {
        Pixel[][] result = quantizeTo2DArray(numColors);
        Util.savePixelMatrixToBitmap(fileName, result);
    }
}
