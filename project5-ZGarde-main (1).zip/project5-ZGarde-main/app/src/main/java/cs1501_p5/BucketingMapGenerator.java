package cs1501_p5;

import java.util.HashMap;
import java.util.Map;



public class BucketingMapGenerator implements ColorMapGenerator_Inter {
    private int numColors;

    public BucketingMapGenerator() {
       
    }

    public BucketingMapGenerator(int numColors) {
        this.numColors = numColors;
    }

    @Override
    public Pixel[] generateColorPalette(Pixel[][] pixelArray, int numColors) {
       Pixel[] palette= new Pixel[numColors];
       
       for (int i=0;i<numColors;i++){
        //double bucketSize=1.0*(1<<24)/numColors;
        //double bucketSize=256.0*256.0*256.0;
        //double mid=bucketSize/2.0;
        //int colorValue=(int)(bucketSize*i+mid);
        int colorValue=(int)((1<<24)*(i+0.5)/numColors); // you cant do /numColors at first, would cause error. i th bucket，i+0.5 so we can find the mid point
        int r = (colorValue >> 16) & 0xFF; // these code change from Util.java r means the highes 8 bit
        int g = (colorValue>> 8) & 0xFF; // mid 8 bits
        int b = colorValue & 0xFF;//lowest
        palette[i]=new Pixel(r,g,b);
       }
       return palette;
    }

    @Override
    public Map<Pixel, Pixel> generateColorMap(Pixel[][] pixelArray, Pixel[] initialColorPalette) {
        Map<Pixel, Pixel> colorMap=new HashMap<>();
        int bucketSize=(int)((1<<24)/numColors); //Like what we did above
        int rowNum= pixelArray.length;
        int colNum= pixelArray[0].length;
        for(int i=0;i<rowNum;i++){
            for(int j=0;j<colNum;j++ ){
                Pixel temp = pixelArray[i][j];
                int colorValue=(temp.getRed() <<16 | temp.getGreen() << 8 | temp.getBlue());
                int bucketIndex= colorValue/bucketSize;
                colorMap.put(temp, initialColorPalette[bucketIndex]);//we put the pixel that we got and its index in the initialColorPalette
            }
        }
        return colorMap;
    
    }

    /* 
    public int getRGBVal(Pixel pixel){
        return (pixel.getRed()<<16) | (pixel.getGreen()<<8) | (pixel.getBlue());


    }
    */
}